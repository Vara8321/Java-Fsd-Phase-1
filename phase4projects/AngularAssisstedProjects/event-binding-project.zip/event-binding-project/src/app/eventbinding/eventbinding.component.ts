import { Component } from '@angular/core';

@Component({
  selector: 'app-eventbinding',
  standalone: true,
  imports: [],
  templateUrl: './eventbinding.component.html',
  styleUrl: './eventbinding.component.css'
})
export class EventbindingComponent {

  animal = `🐶`;

  onClick(){
    alert('Button was clicked');
  }

  onKeyUp(keyUpEvent: any){
      console.log(keyUpEvent);
  }
}
