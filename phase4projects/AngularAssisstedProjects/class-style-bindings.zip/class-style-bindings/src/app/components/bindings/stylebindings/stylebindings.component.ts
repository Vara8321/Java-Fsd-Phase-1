import { Component } from '@angular/core';

@Component({
  selector: 'stylebindings',
  standalone: true,
  imports: [],
  templateUrl: './stylebindings.component.html',
  styleUrl: './stylebindings.component.css'
})
export class StylebindingsComponent {

  isValid: boolean = true;
}
