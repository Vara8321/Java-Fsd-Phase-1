import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StylebindingsComponent } from './stylebindings.component';

describe('StylebindingsComponent', () => {
  let component: StylebindingsComponent;
  let fixture: ComponentFixture<StylebindingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StylebindingsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(StylebindingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
