import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'classbinding',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './classbinding.component.html',
  styleUrl: './classbinding.component.css'
})
export class ClassbindingComponent {

  addHighlight: boolean = false;
}
