
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ClassbindingComponent } from './components/bindings/classbinding/classbinding.component';
import { StylebindingsComponent } from './components/bindings/stylebindings/stylebindings.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ClassbindingComponent, StylebindingsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'class-style-bindings';
}
