import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'propertybinding',
  standalone: true,
  imports: [],
  templateUrl: './propertybinding.component.html',
  styleUrl: './propertybinding.component.css'
})
export class PropertybindingComponent implements OnInit {

  message = `Bound via Propert Binding`;

  constructor(){}

  ngOnInit(): void {
    
  }

  getMessage(){
    console.log("This got called");
    return this.message
  }



}
