import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PropertybindingComponent } from './components/propertybinding/propertybinding.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, PropertybindingComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'property-binding-project';
}
