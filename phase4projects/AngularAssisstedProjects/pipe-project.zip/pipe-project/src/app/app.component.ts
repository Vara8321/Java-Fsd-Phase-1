import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'pipe-project';

  dateToday!: Date;

  price = 5000;

  percentage:number=0.25;

  constructor(){}

  ngOnInit(): void {
      this.dateToday = new Date();
  }
}
