import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { BuiltInStrDirComponent } from './components/built-in-str-dir/built-in-str-dir.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BuiltInAttrDirComponent } from './components/built-in-attr-dir/built-in-attr-dir.component';

@NgModule({
  declarations: [
    AppComponent,
    BuiltInStrDirComponent,
    BuiltInAttrDirComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
