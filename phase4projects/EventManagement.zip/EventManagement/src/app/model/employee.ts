export class Employee {

    id: number = -1;

    first_name: string = "Ramesh";
    last_name: string = "Suresh";
    email: String = "vara@gmbh.com";
    

    constructor(id: number =-1, first_name: string, last_name: string, email: string) {
        this.id = id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.email = email;
    }
}
