import { Injectable } from '@angular/core';
import { Employee } from '../model/employee';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees: Employee[]=[];
  httpClient!: HttpClient;

  restAPIServerBaseUrl: string = "http://localhost:3000";

  constructor(httpClient: HttpClient) {
    this.httpClient = httpClient;
   }

   //List API
  getAllemployees(): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`${this.restAPIServerBaseUrl}/employees`);
  }

   //Delete API
   deleteEmployee = (id: number): Observable<string> => {
    return this.httpClient.delete<string>(`${this.restAPIServerBaseUrl}/employees/${id}`);
  };

   // Create API
   newIdsStart:number=10002;

   addEmployee(first_name: string, last_name: string, email: string): Observable<any>  {
 
     this.newIdsStart=this.newIdsStart+1;
 
     let id: number = this.newIdsStart;   
 
     //let prod: Employee = new Employee(id, name,image, price, true);
     //const prodJSON = JSON.stringify(prod);
 
     let prodJSON={
       "id":""+id,
       "first_name":first_name,
       "last_name":last_name,
       "email":email,
     };
 
     const headers = { 'content-type': 'application/json' };
     
 
     return this.httpClient.post(`${this.restAPIServerBaseUrl}/employees`, prodJSON, { 'headers': headers });
     
   }

   getEmployee = (id: number): Observable<Employee> => {
    return this.httpClient.get<Employee>(`${this.restAPIServerBaseUrl}/employees/${id}`);
  }

  updateEmployee(id:number,first_name: string, last_name: string, email:string): Observable<any>  {
    let prodJSON={
      "id":""+id,
      "first_name":first_name,
      "last_name":last_name,
      "email":email,
    };

    const headers = { 'content-type': 'application/json' };    

    return this.httpClient.put(`${this.restAPIServerBaseUrl}/products/${id}`, prodJSON, { 'headers': headers });
  }
   
}
