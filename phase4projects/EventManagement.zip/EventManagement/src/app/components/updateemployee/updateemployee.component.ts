import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { EmployeeService } from '../../service/employee.service';
import { Employee } from '../../model/employee';
import { ActivatedRoute, Router, RouterLink, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'updateemployee',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule,RouterOutlet,RouterLink,RouterModule],
  templateUrl: './updateemployee.component.html',
  styleUrl: './updateemployee.component.css'
})
export class UpdateemployeeComponent {

  employeeForm!: FormGroup;
  employeeService!: EmployeeService;
  fb!: FormBuilder;

  employee!:Employee;

  router: Router;
  route: ActivatedRoute;

  constructor(router: Router, route: ActivatedRoute, employeeService: EmployeeService, fb: FormBuilder, ) {
    this.employeeService = employeeService;
    this.fb =fb;
    this.route=route; 
    this.router=router;
  }

  ngOnInit(): void {

    this.route.paramMap.subscribe(

      params => {
        const employeeId = params.get('employeeId');

        if (employeeId !== null) {
          this.employeeService.getEmployee(Number(employeeId)).subscribe(
            emp => {
              this.employee = emp;
              this.employeeForm = this.fb.group(
                {
                  employeeFirstName: [this.employee.first_name, [Validators.required, Validators.minLength(3)]],
                  employeeLastName: [this.employee.last_name, [Validators.required, Validators.minLength(3)]],
                  employeeEmail: [this.employee.email, [Validators.required, Validators.minLength(7)]],
                }
              );             
            },

            err => console.log(err)
          );
        }

      }
    );
  }

  updateEmployee= ():void =>  {
    let first_name=this.employeeForm.value.employeeFirstName;
    let last_name = this.employeeForm.value.employeeLastName;
    let email = this.employeeForm.value.employeeEmail ;
    this.employeeService.updateEmployee(this.employee.id,first_name,last_name,email).subscribe(
      result => this.router.navigate(['/employees']),
      error => console.error('Error adding employee:', error)
    );

  }

}
