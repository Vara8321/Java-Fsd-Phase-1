import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Employee } from '../../model/employee';
import { EmployeeService } from '../../service/employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employeedetails',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './employeedetails.component.html',
  styleUrl: './employeedetails.component.css'
})
export class EmployeedetailsComponent implements OnInit {

  employee!: Employee;
  employeeService: EmployeeService;

  route!: ActivatedRoute;

  constructor(employeeService: EmployeeService, route: ActivatedRoute) {
    this.employeeService = employeeService;
    this.route = route;
  }


  ngOnInit(): void {

    this.route.paramMap.subscribe(

      params => {
        const employeeId = params.get('employeeId');

        if (employeeId !== null) {
          this.employeeService.getEmployee(Number(employeeId)).subscribe(
            prod => this.employee = prod,
            err => console.log(err)
          );
        }

      }
    );
  }

  deleteEmployee = (id: number): void => {
    this.employeeService.deleteEmployee(id)
      .subscribe(
        result => console.log("employee deleted"),
        error => console.error('Error deleting product:', error)
      );
  }

  
}
