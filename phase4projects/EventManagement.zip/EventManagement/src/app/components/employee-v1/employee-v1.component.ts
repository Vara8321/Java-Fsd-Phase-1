import { Component } from '@angular/core';
import { Employee } from '../../model/employee';
import { EmployeeService } from '../../service/employee.service';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { EmployeedetailsComponent } from '../employeedetails/employeedetails.component';

@Component({
  selector: 'app-employee-v1',
  standalone: true,
  imports: [CommonModule, RouterLink,RouterOutlet, EmployeedetailsComponent],
  templateUrl: './employee-v1.component.html',
  styleUrl: './employee-v1.component.css'
})
export class EmployeeV1Component {

  employees!: Employee[];

  employeeserviceV1!: EmployeeService;
  router:Router

  constructor(router:Router, employeeserviceV1: EmployeeService) {
    this.employeeserviceV1 = employeeserviceV1;
    this.router=router;
  }


  ngOnInit(): void {

    this.employeeserviceV1.getAllemployees()
      .subscribe(
        data => this.employees = data,
        err => console.error('Error fetching employees:', err)
      );

  }
}
