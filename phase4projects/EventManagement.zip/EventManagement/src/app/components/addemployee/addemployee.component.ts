import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { EmployeeService } from '../../service/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addemployee',
  standalone: true,
  imports: [CommonModule,FormsModule,ReactiveFormsModule],
  templateUrl: './addemployee.component.html',
  styleUrl: './addemployee.component.css'
})
export class AddemployeeComponent {

  employeeForm!: FormGroup;
  employeeService!: EmployeeService;
  fb!: FormBuilder;

  router: Router;

  constructor(router: Router, employeeService: EmployeeService, fb: FormBuilder, ) {
    this.employeeService = employeeService;
    this.fb =fb;
    this.router=router;
    
    this.employeeForm = this.fb.group(
      {
        employeeFirstName: ['', [Validators.required, Validators.minLength(3)]],
        employeeLastName: ['', [Validators.required, Validators.minLength(3)]],
        employeeEmail: ['', [Validators.required, Validators.minLength(7)]], 
      }
    );
  }

  addEmployee= ():void =>  {
    let first_name=this.employeeForm.value.employeeFirstName;
    let last_name = this.employeeForm.value.employeeLastName;
    let email = this.employeeForm.value.employeeEmail ;
    this.employeeService.addEmployee(first_name,last_name,email).subscribe(
      result => this.router.navigate(['/employees']),
      error => console.error('Error adding employee:', error)
    );

  }
}
