import { Component } from '@angular/core';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { EmployeeV1Component } from './components/employee-v1/employee-v1.component';
import { CommonModule } from '@angular/common';
import { EmployeedetailsComponent } from './components/employeedetails/employeedetails.component';
import { AddemployeeComponent } from './components/addemployee/addemployee.component';
import { UpdateemployeeComponent } from './components/updateemployee/updateemployee.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, HomeComponent,
    RouterLink, EmployeeV1Component,RouterModule, CommonModule, 
    EmployeedetailsComponent, AddemployeeComponent, UpdateemployeeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'EventManagement';
}
