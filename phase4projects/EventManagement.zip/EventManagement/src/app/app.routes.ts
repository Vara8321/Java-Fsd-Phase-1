import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { EmployeeV1Component } from './components/employee-v1/employee-v1.component';
import { EmployeedetailsComponent } from './components/employeedetails/employeedetails.component';
import { AddemployeeComponent } from './components/addemployee/addemployee.component';
import { UpdateemployeeComponent } from './components/updateemployee/updateemployee.component';

export const routes: Routes = [
    { path: "home", component: HomeComponent},
    { path: "employees", component: EmployeeV1Component},
    { path: 'employee/:employeeId', component: EmployeedetailsComponent},
    { path: 'add-employee', component: AddemployeeComponent},
    { path: 'update-employee/:employeeId', component: UpdateemployeeComponent}
];
